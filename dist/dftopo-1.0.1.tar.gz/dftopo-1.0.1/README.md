# DFTOPO

Pass postgres data to pandas dataframe
Read data from postgres in python
Load data from python to Postgres
