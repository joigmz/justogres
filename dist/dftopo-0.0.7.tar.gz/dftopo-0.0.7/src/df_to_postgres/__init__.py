cd  dataframe_to_postgres/df_to_postgres
vim  __init__.py
import dfps